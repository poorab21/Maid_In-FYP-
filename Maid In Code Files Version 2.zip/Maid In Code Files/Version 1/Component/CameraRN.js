import { useEffect, useState } from "react";
import {
    StyleSheet,
    Text,
    View,
    Pressable,
    PermissionsAndroid,
    Platform,
    Image,
    Alert
} from 'react-native';

import { launchCamera } from "react-native-image-picker";

const CameraRN = () => {
    const [filePath,setFilePath] = useState(null);

    const requestCameraPermission = async () => {
        if(Platform.OS === 'android'){
            try {
                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.CAMERA,
                    {
                        title : 'Camera Permissions',
                        message : 'MaidIn requires access to your device camera'
                    }
                );
                return granted === PermissionsAndroid.RESULTS.GRANTED;
            }
            catch(err){
                return false;
            }
        }
        else return true;
    }
    const captureImage = async () => {
        let options = {
            mediaType : 'photo',
            maxWidth : 300,
            maxHeight : 550,
            quality  : 1,
            videoQuality : 'low',
            durationLimit : 30,
            saveToPhotos : true
        }
        let isCameraPermitted = await requestCameraPermission();
        if(isCameraPermitted){
            launchCamera(options,(response)=>{
                if(response.errorCode == 'camera_unavailable'){
                    Alert.alert(
                        'Camera Status',
                        'Camera not Available on Device',
                    )
                    return;
                }
                else if(response.errorCode == 'permission'){
                    Alert.alert(
                        'Camera Status',
                        'Permissions not Satisfied',
                    )
                    return;
                }
                else if(response.errorCode == 'others'){
                    Alert.alert(
                        'Camera Status',
                        response.errorCode,
                    )
                    return;
                }
                setFilePath(response);
            })
        }
    }

    

    return (
        <View style = {{borderWidth : 5,display : 'flex',justifyContent : 'center',padding : 30}}>
            <Pressable 
            onPress={captureImage}>
                <Text style = {{textAlign : 'center'}}>
                    Capture Image
                </Text>
            </Pressable>
            {
                filePath != null ?
                <Image
                style = {{width : 500,height : 300}}
                source={{uri : filePath.assets[0].uri }} /> : null
            }
        </View>
    )
}

export default CameraRN;