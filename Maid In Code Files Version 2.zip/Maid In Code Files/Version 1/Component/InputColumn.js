import React from 'react';
import {
  Text, 
  View ,
  StyleSheet,
} from 'react-native';

const styles = StyleSheet.create({
  row : {
    display : 'flex',
    flexDirection : 'row',
    flex : 1,
    margin : 10,
},
  firstField : {
    flex : 1,
    borderWidth : 3,
    borderRadius : 10
  },  
  SecondField : {
    flex : 1,
    borderWidth : 3,
    marginLeft : 10,
    borderRadius : 10
  },
  fieldLabel : {
    textAlign : 'center',
    fontWeight : 'bold',
    fontSize : 15
  },
})

const InputColumn = (props) => {
  const {fieldname1,icon1,setFieldState1,state1,icon2,error_message,state2,setFieldState2,setFocused} = props;
  return (
    <View style = {styles.row}>
      <View style = {styles.firstField}>
        <Text style = {styles.fieldLabel}>{fieldname1}</Text>
          <Input 
            leftIcon = {{type : 'font-awesome' , name : icon1}}
            onChangeText = {setFieldState1}
            value = {state1}
          />   
      </View>
      <View style = {styles.SecondField}>
        <Text style = {styles.fieldLabel}>{fieldname2}</Text>
          <Input 
            onFocus={() => setFocused(true)}
            onBlur = {() =>  setFocused(false)}
            { ...( emailFocused && !emailCriteria.test(email) ? { errorMessage : error_message } : {} )}
            leftIcon = {{type : 'font-awesome' , name : icon2}}
            onChangeText = {setFieldState2}
            value = {state2}
          />   
      </View>
    </View>
  )
}

export default InputColumn;