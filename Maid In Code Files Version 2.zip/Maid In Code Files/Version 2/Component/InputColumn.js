import React from 'react';
import {
  Text, 
  View ,
  StyleSheet,
} from 'react-native';

import { Input } from 'react-native-elements';

const styles = StyleSheet.create({
  row : {
    display : 'flex',
    flexDirection : 'row',
    flex : 1,
    margin : 10,
},
  firstField : {
    flex : 1,
    borderWidth : 3,
    borderRadius : 10
  },  
  SecondField : {
    flex : 1,
    borderWidth : 3,
    marginLeft : 10,
    borderRadius : 10
  },
  fieldLabel : {
    textAlign : 'center',
    fontWeight : 'bold',
    fontSize : 15
  },
})

const InputColumn = (props) => {
  const {
    fieldname1,
    fieldname2,
    icon1,
    icon2,
    setFieldState1,
    state1,
    setFieldState2,
    state2,
    error_message1,
    error_message2,
    setFocused1,
    setFocused2,
    focused1,
    focused2,
    criteria1,
    criteria2
  } = props;
  return (
    <View style = {styles.row}>
      <View style = {styles.firstField}>
        <Text style = {styles.fieldLabel}>{fieldname1}</Text>
          <Input
            onFocus={() => setFocused1(true)}
            onBlur = {() =>  setFocused1(false)}
            { ...( focused1 && !criteria1.test(state1) ? { errorMessage : error_message1 } : {} )}
            leftIcon = {{type : 'font-awesome' , name : icon1 }} 
            onChangeText = {setFieldState1} 
            value = {state1} />   
      </View>
      <View style = {styles.SecondField}>
        <Text style = {styles.fieldLabel}>{fieldname2}</Text>
          <Input 
            onFocus={() => setFocused2(true)}
            onBlur = {() =>  setFocused2(false)}
            { ...( focused2 && !criteria2.test(state2) ? { errorMessage : error_message2 } : {} )}
            leftIcon = {{type : 'font-awesome' , name : icon2 }} 
            onChangeText = {setFieldState2}
            value = {state2}
          />   
      </View>
    </View>
  )
}

export default InputColumn;